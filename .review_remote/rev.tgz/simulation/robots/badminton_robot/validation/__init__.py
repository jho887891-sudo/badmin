"""Validation helpers."""
